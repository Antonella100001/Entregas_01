print("    *")
print("   * *")
print("  *   *")
print(" *     *")
print("***   ***")
print("  *   *")
print("  *   *")
print("  *****")

#imprimir una unica flecha
print("    *","   * *","  *   *"," *     *","***   ***","  *   *","  *   *","  *****", sep= ("\n"))

#Hacer la flecha el doble de grande
print("       *")
print("      * *")
print("     *   *")
print("    *     *")
print("   *       *")
print("  *         *")
print(" *           *")
print("****       ****")
print("   *       *")
print("   *       *")
print("   *       *")
print("   *       *")
print("   *********")

# Duplicar la flecha, colocando ambas flechas lado a lado
print("      *    "*2)
print("     * *   "*2)
print("    *   *  "*2)
print("   *     * "*2)
print("  ***   ***"*2)
print("    *   *  "*2)
print("    *   *  "*2)
print("    *****  "*2)


print(0.0000000000000000000001)

print("I'm 'Monty Python'.")

print(True > False)
print(True < False)

print('"estoy"','""aprendiendo""','"""Python"""', sep= "\n")

#Exponenciales
print(2 ** 3)
print(2 ** 3.)
print(2. ** 3)
print(2. ** 3.)

