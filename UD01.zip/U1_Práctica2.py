hectáreas = float(input("Introduce el número de hectáreas: "))

hectárea1 = hectáreas * 10000
campoFutbol = int(hectárea1) / 7350
campoBaloncesto = int(hectárea1) / 420
campoTenis = int(hectárea1) / 260.7569
parqueRetiro = int(hectárea1) / 1250000

print ("La equivalencia en referencia a un campo de futbol es,",round(campoFutbol,3))
print ("La equivalencia en referencia a un campo de baloncesto es,",round(campoBaloncesto,3))
print ("La equivalencia en referencia a un campo de tenis es,",round(campoTenis,3))
print ("La equivalencia en referencia al parque Retiro es,",round(parqueRetiro,3))
