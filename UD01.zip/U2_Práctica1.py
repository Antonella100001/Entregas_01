ra = 3 / 2 + 4 / 3
rb = 1 / (x - 5) - (3*x*y) / 4
rc = 1 / 2 + 7
rd
re
rf
rg
rh
ri
rj= (3 * a + b) / (c - ((d + 5 * e ) / (f + (g / (2*h)))))

#203

a = 8
b = 3
c = -5
print ("i", (a * -c)% b)
print ("j", a * (-c % b))
print ("k",(3 * a - 2 * b) % (2 * a - c))

#206
w = False
X = True
Y = True
Z = False

print ("a", W or Y and X and W or Z)
print ("b", X and !Y and !X or !W and Y)
print ("d", X and Y and W or Z or X)
print ("e", Y or !(Y or Z and W))
print ("c", not(W or not Y) and X or Z)
print ("f", not X and Y and (not Z or not X))


#207

i = 8
j = 5
x = 0.005
y = -0.01

print("A", i<=j)
print("B", j != 6)
print("D", not(i <= j))
print("F", -j == i - 13)
print("G", 2 * x + y == 0)
print("H", 2 * x + (y == 0))
print("j", -(i + j) != -i + j)
print("k", i <= j and i >= c)#false
print("k", i <= j and i >= c or True)#true

#301

A = -123
A4 = 4567
precio = 10
 
print("E", A % 10 / 2) # 1.5
print("F", A % 10 + A % 100 // 10 + A // 100) # 6
print("H", A % 2 == 0 and A % 3 == 0) #
print("Hb", A % 6 == 0) # porque 6 es el m.c.m. de 2 y 3
print("K", A4 // 1000 % 2 == 0) #
print("M", precio >= 10 and precio < 50) #
print("Mb", 10 <= precio < 50) # Sintaxis permitida en Python?
 
#...
 
A = 5 if A < 0 else 100
print("JJ", A)



