entradaInfantil = int(input("Cantidad de entradas infantiles:"))
entradaAdulto = int(input("Cantidad de entradas adultos:"))

importeBase = entradaAdulto * 20 + entradaInfantil * 15.5
importeFinal = importeBase * 0.95 if importeBase >= 100 else importeBase

print ("Importe final", importeFinal, "€")

#cambio a constantes
PRECIO_ENTRADAS_ADULTO = 20
PRECIO_ENTRADAS_INFANTIL = 15.5
UMBRAL_DESCUENTO = 100
PORCENTAJE_DESCUENTO = 5

entradaInfantil = int(input("Cantidad de entradas infantiles:"))
entradaAdulto = int(input("Cantidad de entradas adultos:"))

importeBase = PRECIO_ENTRADAS_ADULTO + PRECIO_ENTRADAS_INFANTIL
importeDescuento = importeBase * PORCENTAJE_DESCUENTO / 100
importeFinal = importeBase - importeDescuento if importeBase >= 100 else importeBase

print ("Importe final", importeFinal, "€")
