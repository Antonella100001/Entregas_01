# Escribe un programa que tome como entrada un número entero e indique qué cantidad hay que sumarle para que el resultado sea múltiplo de 7

numero = int( input ("Introduce un número entero: "))

resto = numero % 7

solución = 7 - resto

print("Para obtener un numero multiplo de 7 debemos sumar", solución, "a", numero)

#numero resto solucion
#5       5      2
#13      6      1
#9       2      5
#7       0      0



