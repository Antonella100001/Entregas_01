#Érase una vez en la Tierra de las Manzanas, Juan tenía tres manzanas, María tenía cinco manzanas, y Adán tenía seis manzanas. Todos eran muy felices y vivieron por muchísimo tiempo. Fin de la Historia.

juan = 3
maria = 5
adan = 6

print (juan, maria, adan, sep=",")

total_manzanas = (juan + maria + adan)

print (total_manzanas)



kilometers = 12.25
miles = 7.38
conversion = 1.61

miles_to_kilometers = miles * conversion
kilometers_to_miles = kilometers/conversion



print(miles, "millas son", round(miles_to_kilometers, 2), "kilómetros")
print(kilometers, "kilómetros son", round(kilometers_to_miles, 2), "millas")

#El codigo a escribir es la operación matematica de multiplación suma resta exponente
#Exponente es **
x = 0

x = float(x)

y = 3*(x**3)-2*(x**2)+3*x - 1
print("y =", y)


x = 1

x = float(x)

y = 3*(x**3)-2*(x**2)+3*x - 1
print("y =", y)


x = -1

x = float(x)

y = 3*(x**3)-2*(x**2)+3*x - 1
print("y =", y)


