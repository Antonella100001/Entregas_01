Python 3.10.7 (tags/v3.10.7:6cc6b13, Sep  5 2022, 14:08:36) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

#Expresión con multiples parentesis y uso de diferentes operadores
print((5 * ((25 % 13) + 100) / (2 * 13)) // 2)


