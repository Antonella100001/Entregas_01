hour = int(input("Hora de inicio (horas): "))
mins = int(input("Minuto de inicio (minutos): "))
dura = int(input("Duración del evento (minutos): "))

# Escribe tu código aqui.Prof
finalhour = hour + (mins + dura)//60
finalMins = (mins + dura) %60

print (str(finalhour) + ":" + str(finalMins))

#resolucion aparte
durationhours = dura/60+hour
minutes = (mins + dura) %60
hours = int(hour + (mins +dura) / 60) % 24
print(hours,":",minutes,sep="")
