medida_uno = float(input("Introduce la primera medida en milimetros"))
medida_dos = float(input("Introduce la segunda medida en centimetros"))
medida_tres = float(input("Introduce la última medida en metros"))

x = medida_uno / 10
y = medida_tres * 100

suma = x + y + medida_dos

print("El resultado es", suma, "cm")
