programación = 240
sesión = 50
tiempo_total = programación * 60
clase = tiempo_total // sesión
apercibimiento = clase * 0.06
perdidaEvalución = clase * 0.1

print("El número de faltas sin justificar que implican un apercibimiento es:", round(apercibimiento,0))
print("El número de faltas sin justificar para pérdida de evaluación continua es:", round(perdidaEvalución,0))


programación = int(input("Introduce el número de horas:"))
sesión = int(input("Introduce el número de sesiones:"))
falta = int(input("Introduce el número de clases no acudidas:"))

#valor_si_verdadero if condicion else valor_si_falso, se puede colocar la condicion solamente 
tiempo_total = programación * 60
claseReal = tiempo_total // sesión
apercibimiento = claseReal * 0.06
perdidaEvaluación = claseReal * 0.1
apercibimiento = falta > apercibimiento
perdida = falta > perdidaEvaluación
print("Apercibimiento" if apercibimiento else "")
print("Perdida" if perdida else "")



