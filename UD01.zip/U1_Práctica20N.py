ra = 3 / 2 + 4 / 3
rb = 1 / (x - 5) - (3*x*y) / 4
rc = 1 / 2 + 7
rd
re
rf
rg
rh
ri
rj= (3 * a + b) / (c - ((d + 5 * e ) / (f + (g / (2*h)))))

#203

a = 8
b = 3
c = -5
print ("i", (a * -c)% b)
print ("j", a * (-c % b))
print ("k",(3 * a - 2 * b) % (2 * a - c))

#205

X = True
Y = False
Z = True
print("A", (X and Y) or (X ans Z))
print("B", (X or not Y) and (not X or Z))
