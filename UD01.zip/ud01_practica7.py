print ("Cálculo de polinomios de segundo grado")
a = float( input("Introduce el valor de \"a\":"))
b = float( input("Introduce el valor de \"b\":"))
c = float( input("Introduce el valor de \"c\":"))
x = float( input("Introduce el valor de \"x\":"))

y = a * x ** 2 + b * x + c

print("El resultado es", y)
