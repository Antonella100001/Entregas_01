km = float( input("Introduce la distancia del trayecto recorrido en km;"))
consumo = float( input("Introduce el consumo meio en litros por cada 100 km"))
euros_litros = float( input("Introduce el precio por litro"))
personas = float( input("Introduce el total de pasjeros con conductor incluido"))


litros_totales = km * consumo / 100
precio_litro= litros_totales * euros_litros

litros_totales2 = consumo /100
precio_litro_km= litros_totales2 * euros_litros

precio_total = precio_litro + precio_litro_km
precio_pasajero = precio_total / personas

print ("El importante total estimado es,", round(precio_litro,2))
print ("El importe medio por kilometro es,", round(precio_litro_km,2))
print ("El importante total por pasajero es,", round(precio_pasajero,2))
