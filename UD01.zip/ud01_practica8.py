tiempo = int(input("Introduce una cantidad de segundos:"))

segundos = tiempo %60
#% y // estan en el mismo nivel de jerarquia para realizar la operación por lo que no es necesario poner los parentesis
minutos = (tiempo // 60)%60
horas = (tiempo // 3600)

print (horas,"horas", minutos,"minutos", segundos,"segundos")
