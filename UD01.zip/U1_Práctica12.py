INTERES = 4

importeInicial = float(input("Introduce importe inicial"))
importeAnho1 = importeInicial + importeInicial * INTERES / 100
importeAnho2 = importeAnho1 + importeAnho1 * INTERES / 100
importeAnho3 = importeAnho2 + importeAnho2 * INTERES / 100

print("Ahorros año 1:", round(importeAnho1,2))
print("Ahorros año 2:", round(importeAnho2,2))
print("Ahorros año 2:"round(importeAnho3,2))


#otra forma
INTERES = 4
importe = float(input("Importe inicial: "))
 
# Proceso
importe *= 1 + INTERES / 100
print("Ahorros Año 1:", round(importe, 2))
 
importe *= 1 + INTERES / 100
print("Ahorros Año 2:", round(importe, 2))
 
importe *= 1 + INTERES / 100
print("Ahorros Año 3:", round(importe, 2))
