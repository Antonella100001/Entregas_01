#Crea un programa que pida la base y la altura de un triángulo y muestre su área.

base = float ( input ("Introduce la base:  "))
altura = float ( input ("Introduce la altura:  "))

Área_Triángulo = (base * altura) / 2

print ("El área del triángulo es", Área_Triángulo)
