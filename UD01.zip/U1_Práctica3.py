print ("https://www.recetasderechupete.com/compota-de-manzana-casera/12509/")
print ("Receta de compota de manzana")
print ("La receta está pensada para 6 personas. Utiliza 1kg y medio de manzanas, 330ml de agua, 120g. de azúcar y una cucharadita de zumo de limón"
