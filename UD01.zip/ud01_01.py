#Un economista te ha encargado un programa para realizar cálculos con el IVA. La aplicación debe solicitar la base imponible y el IVA que se debe aplicar.
#Muestra en pantalla el importe correspondiente al IVA y al total.

x = float(input ("Intotudece la base imponible: "))
y = float(input ("Introduce el % del IVA: "))

#Usamo float en vez de int para introducir valores no enteros


precio_iva = x * y / 100
precio_total = x + precio_iva

print ("El importe toltal es" , round(precio_total,2) , "€")
print ("El importe del IVA es", round(precio_iva,2), "€")

#round, pone decimales para ello debes colocar el número de decimales que quieres
