importe = float(input("Importe inicial:"))
interes = float(input("Interés anual: "))
anhos = int(input("Número de años: "))

importeFinal = importe * (1 + interes/100)**anhos
print("Importe final:", round(importeFinal, 2))






