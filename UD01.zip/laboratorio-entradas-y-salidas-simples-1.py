# ingresa un valor flotante para la variable a aquí
a = float(input("Introduce el valor de la variable a:"))
# ingresa un valor flotante para la variable b aquí
b = float(input("Introduce el valor de la variable b:"))

# muestra el resultado de la suma aquí
suma = a + b
print("La suma de a y b es" + str(suma))
print("La suma de a y b es", suma)
# muestra el resultado de la resta aquí
resta = a - b
print("La resta de a y b es" + str(a - b))
# muestra el resultado de la multiplicación aquí
division = a / b
print("La division de a y b es" + str(round(a / b, 2)))
# muestra el resultado de la división aquí
multiplicacion = a * b
print("La division de a y b es" + str(a * b))

print("\n¡Eso es todo, amigos!")



